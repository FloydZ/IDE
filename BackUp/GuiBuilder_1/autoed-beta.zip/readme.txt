pressing Ctrl+space brings up dropdown list of autoit functions/macros and send keys
pressing Ctrl+J brings up auto completion.
code completion also exists for all autoit functions, ie: typing in
ControlClick("hint",hint,etc,etc . pops in after pressing the "(" bracket
AutoCompletion is also present when typing, certain "trigger chars" will
fire the execute event. these chars can be modified in Environment options

F9 will run AutoIt and if erros will output to console window
F8 will run Au3Check and do a syntax check on the script.
F10 will shellexecute AutoIt and report in the normal way (no console)




December 5th, 2004
added code explorer. AutoEd is now multi threaded.

November 27th,2004
added options to set path to AutoIt3.exe and Au3Check.exe and save to
Ini file.

November 23rd,2004
added syntax check(Thanks AutoIt3 Syntax Checker v1.12, Tylo ) with integrated console out window, syntax errors
are highlighted automatically.
added run Autoit with /ErrorStdOut switch to pipe output to console window
error are highlighted automatically.


November 14th,2004
added Snippets Library. save small pieces of often used code to the
snippets library and access them from the drop down ComboBox. 
It will insert the code at the current cursor position.


November 11th,2004
added color to autocomplete "Function,Macro and Send Key" 
added Search, Search & Replace
added MRU (recent files) 
added Highlight ActiveLine
added config tools for above in Tools->Environment option->Misc
Determined backwards compatibility with Delphi 5, switched to Delphi 6
enabling 2000 style Open/Close Dialogs


November 9th,2004
added Option to add remove trigger characters for autocompletion
in "Tools->Environment Options -> Misc"
fixed statusbar update onclick event
added Goto Line Dialog

November 7th,2004
Fixed Editor Options dialog not saving some info to ini file.
particularly caret behaviour (scroll past end of line)
added all the GUI keywords to autoitlist.dat and autoitinsert.dat (Thanks Evan!)
added GUI keywords to colors.ini.
added info on colors.ini

November 6th,2004

fixed caret/cursor not showing up on startup page.
fixed codecompletion template not showing up on startup page. (CTRL+J)
fixed problem with saving font
removed all trigger charactors except @ and { for autocompletion dropdown
Ctrl+space and the above two charactors will initialize autocomplete
"File Open" now defaults to only AutoIt files and All files

November 4th,2004

Very alpha state for testing purposes only.

todo: 

compiler results console window
code explorer
form designer

regards
Martin
